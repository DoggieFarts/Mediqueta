<?php

//conexión a base de datos

$servidor="localhost";
$usuario="root";
$clave="";
$db="mediqueta2";

$enlace= mysqli_connect($servidor,$usuario,$clave,$db);
if(!$enlace){
    
    echo "Error con la conexión en el servidor";
    
}


?>